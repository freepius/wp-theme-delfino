# Delfino

WordPress theme for Claire Delfino website: https://clairedelfino.com

# TODO

- [ ] Use WordPress translation functions for everything
- [ ] Transform the **Collapser** feature into a WordPress plugin
- [ ] Transform the **Gallery** feature into a WordPress plugin
- [ ] Use ESLint and WordPress coding standards for Javascript?
- [ ] Use stylint and WordPress coding standards for CSS and SCSS?
- [ ] Use Travis CI or GitHub CI!
